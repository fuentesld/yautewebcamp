### Required Information

- PHP Version:
- PayPal-PHP-SDK Version:
- Debug ID(s):

### Issue Description
> Please include as many details (logs, steps to reproduce) as you can to help us reproduce this issue faster.
