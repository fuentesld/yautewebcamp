<nav>
      <a href="ver_registrados.php">Ver Registrados</a>|
      <a href="agregar_invitado.php">Agregar Invitado</a>|
      <a href="agregar_categoria.php">Agregar Categoria</a>|
      <a href="agregar_evento.php">Agregar Evento</a>|
      <a href="crear_admin.php">Agregar Admin</a>|
      <a href="cerrar_sesion.php">Cerrar Sesión</a>|
</nav>